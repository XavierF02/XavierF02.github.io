$(document).ready(function() {
    $("#slider").bxSlider({
        moveSlides: 1,
        minSlides: 1,
        maxSlides: 1,
        captions: false,
        auto: true,
        pause: 8000,
        speed: 1000,
        stopAutoOnClick: true
    });
});