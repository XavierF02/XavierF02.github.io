$(document).ready(function() {
    $("#about").accordion({
        event: "click",
        heightStyle: "content",
        collapsible: true
    });
});